import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataStoreService } from '../data-store.service';

@Component({
  selector: 'app-display-list',
  templateUrl: './display-list.component.html',
  styleUrls: ['./display-list.component.css']
})
export class DisplayListComponent implements OnInit {

  constructor(private store: DataStoreService, private route : Router) { }
  listData = [];
  editflag = true;
  editflag1 = true;
  editFlagList  = [];
  emptyFlag = false;

  ngOnInit(): void {

   this.listData =  this.store.allData;

   if (  this.listData.length == 0) {
    this.emptyFlag = true;
    setTimeout(() => {
      this.route.navigate(['create']);
    }, 3000);
  
   }

   for (let aa of this.listData) {
    this.editFlagList.push(true);
   }
  }

  deleteRow(i) {
    this.listData.splice(i,1);
    if (this.listData.length ==0)
    this.emptyFlag = true;

  }

  editRow(i) {
    this.editFlagList[i] = false;;

  }

  saveRow(i)  {
    this.editFlagList[i] = true;;

  }

}
