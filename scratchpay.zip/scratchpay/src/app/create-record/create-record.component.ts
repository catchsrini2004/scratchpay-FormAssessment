import { Component, OnInit } from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  Validators
} from '@angular/forms';
import { DataStoreService } from '../data-store.service';
import Validation from '../utils/validation';

@Component({
  selector: 'app-create-record',
  templateUrl: './create-record.component.html',
  styleUrls: ['./create-record.component.css']
})
export class CreateRecordComponent implements OnInit {

   
  form: FormGroup;
  submitted = false;
  duprecord = false;
  dupEmail = false

  constructor(private formBuilder: FormBuilder, private store: DataStoreService) {}

  ngOnInit(): void {
    this.form = this.formBuilder.group(
      {

        id: ['', [Validators.required,    
        Validators.minLength(2),
       Validators.maxLength(10)]],

        firstname: ['', [Validators.required,    
         Validators.minLength(2),
        Validators.maxLength(20)]],
        lastname: [
          '',
          [
            Validators.required,
            Validators.minLength(2),
            Validators.maxLength(20)
          ]
        ],
      
        role: [
          '',[
            Validators.required
          ]
        ],
        status: ['', [Validators.required]],
        email: ['', [Validators.required, Validators.email]],
      
      },
      
    );
  }

  get f(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }

  onSubmit(): void {
    this.submitted = true;
    this.duprecord = false;
    this.dupEmail = false;

    if (this.form.invalid) {
      return;
    }
    for(let obj of this.store.allData) {
      if (obj.id == this.form.get('id').value ) {
        this.duprecord = true;
        return;

      }

      if (obj.email == this.form.get('email').value ) {
        this.dupEmail = true;
        return;

      }
    }


    this.store.allData.push(this.form.value);

    //console.log(JSON.stringify(this.form.value, null, 2));
  }

  onReset(): void {
    this.submitted = false;
    this.form.reset();
    this.duprecord = false;
    this.dupEmail = false;
  }
}
