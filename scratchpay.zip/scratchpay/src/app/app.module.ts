import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { CreateRecordComponent } from './create-record/create-record.component';
import { DisplayListComponent } from './display-list/display-list.component';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {path: '', pathMatch: 'full', redirectTo: 'create'},
  {path: 'create', component: CreateRecordComponent},
  {path: 'list', component: DisplayListComponent}
 
];

 

@NgModule({
  imports: [BrowserModule, ReactiveFormsModule,FormsModule, RouterModule.forRoot(routes)],
  exports: [RouterModule],
  declarations: [AppComponent, CreateRecordComponent, DisplayListComponent],
  bootstrap: [AppComponent]
})
export class AppModule {}
